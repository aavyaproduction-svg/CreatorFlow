import { useState, useEffect, useCallback } from 'react';
import { v4 as uuidv4 } from 'uuid';

const EXTENSION_ID = process.env.NEXT_PUBLIC_EXTENSION_ID || "your_chrome_extension_id_here";

type ExtensionState = 'CHECKING' | 'NOT_INSTALLED' | 'CONNECTED' | 'ERROR';

export function useCreatorFlowExtension() {
  const [status, setStatus] = useState<ExtensionState>('CHECKING');
  const [version, setVersion] = useState<string | null>(null);

  const sendRequest = useCallback(async (action: string, payload: any = {}) => {
    return new Promise((resolve, reject) => {
      if (typeof window === 'undefined' || !(window as any).chrome || !(window as any).chrome.runtime) {
        return reject('CHROME_API_NOT_AVAILABLE');
      }

      const requestId = uuidv4();
      const timeoutId = setTimeout(() => reject('EXTENSION_TIMEOUT'), 15000);

      (window as any).chrome.runtime.sendMessage(
        EXTENSION_ID,
        { requestId, action, payload },
        (response: any) => {
          clearTimeout(timeoutId);
          if ((window as any).chrome.runtime.lastError) {
            return reject('EXTENSION_COMMUNICATION_FAILED');
          }
          if (response && response.success) {
            resolve(response.data);
          } else {
            reject(response?.error || 'UNKNOWN_ERROR');
          }
        }
      );
    });
  }, []);

  useEffect(() => {
    let mounted = true;
    const checkExtension = async () => {
      try {
        const res: any = await sendRequest('PING');
        if (mounted) {
          setStatus('CONNECTED');
          setVersion(res.version);
        }
      } catch (err) {
        if (mounted) setStatus('NOT_INSTALLED');
      }
    };
    checkExtension();
    return () => { mounted = false; };
  }, [sendRequest]);

  return { status, version, sendRequest };
}