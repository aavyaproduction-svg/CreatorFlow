"use client";

import { useState } from 'react';
import { useCreatorFlowExtension } from '@/lib/extension/useExtension';
import { CheckCircle, AlertCircle, ArrowRight, Loader2, ShieldCheck } from 'lucide-react';

const isDemoMode = process.env.NEXT_PUBLIC_DEMO_MODE === 'true';

export default function PayoutTransferPage() {
  const { status, sendRequest } = useCreatorFlowExtension();
  const [step, setStep] = useState(1);
  const [sources, setSources] = useState<any[]>([]);
  const [selectedSource, setSelectedSource] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const fetchSources = async () => {
    setIsLoading(true);
    try {
      const data: any = isDemoMode 
        ? { sources: [{ id: "demo_1", name: "Demo Gaming Page", balance: "$2,000.00" }] }
        : await sendRequest('GET_PAYOUT_SOURCES');
      
      setSources(data.sources);
      setStep(2);
    } catch (error) {
      console.error(error);
      alert("Failed to fetch sources. Make sure you are logged into Facebook.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleTransfer = async () => {
    setIsLoading(true);
    try {
      const extensionResult: any = await sendRequest('EXECUTE_TRANSFER', {
        sourceId: selectedSource,
        destinationId: "DEST_123"
      });

      if (!extensionResult || !extensionResult.referenceId) {
        throw new Error("Transfer failed.");
      }
      setStep(3);
    } catch (error: any) {
      console.error("Transfer error:", error);
      alert(`Transfer failed: ${error.message || error}`);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto p-6 space-y-8">
      {/* ... (UI implementation matches earlier snippets) ... */}
      <h1 className="text-3xl font-bold text-gray-900">Facebook Payout Transfer UI Placeholder</h1>
    </div>
  );
}