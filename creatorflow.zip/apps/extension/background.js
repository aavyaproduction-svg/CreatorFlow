const ALLOWED_ORIGINS = [
  "https://app.creatorflow.io",
  "http://localhost:3000"
];

const ALLOWED_ACTIONS = [
  "PING",
  "GET_PAYOUT_SOURCES",
  "EXECUTE_TRANSFER"
];

function validatePayload(action, payload) {
  if (action === "EXECUTE_TRANSFER") {
    if (!payload || typeof payload.sourceId !== 'string' || typeof payload.destinationId !== 'string') {
      throw new Error("Invalid transfer payload schema");
    }
  }
  return true;
}

chrome.runtime.onMessageExternal.addListener((request, sender, sendResponse) => {
  const { requestId, action, payload } = request;

  if (!ALLOWED_ORIGINS.includes(sender.origin)) {
    return false; 
  }

  if (!ALLOWED_ACTIONS.includes(action)) {
    sendResponse({ requestId, success: false, error: "UNAUTHORIZED_ACTION" });
    return false;
  }

  try {
    validatePayload(action, payload);

    if (action === "PING") {
      sendResponse({ requestId, success: true, data: { version: "1.0.0", status: "READY" } });
    } else if (action === "GET_PAYOUT_SOURCES") {
      executeFacebookGraphFetch('/me/payout_sources')
        .then(data => sendResponse({ requestId, success: true, data }))
        .catch(error => sendResponse({ requestId, success: false, error: "FB_API_ERROR" }));
      return true;
    } else if (action === "EXECUTE_TRANSFER") {
      executeFacebookTransfer(payload.sourceId, payload.destinationId)
        .then(result => sendResponse({ requestId, success: true, data: result }))
        .catch(error => sendResponse({ requestId, success: false, error: error.message }));
      return true; 
    }
  } catch (err) {
    sendResponse({ requestId, success: false, error: "VALIDATION_FAILED" });
  }
});

async function executeFacebookGraphFetch(path) {
  return { sources: [{ id: "src_1", name: "Main Page" }] }; 
}

async function executeFacebookTransfer(sourceId, destId) {
  return { referenceId: "TX_" + Math.random().toString(36).substr(2, 9) };
}